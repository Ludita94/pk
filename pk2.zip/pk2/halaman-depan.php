<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <title>Login PK-Applications</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Charisma, a fully featured, responsive, HTML5, Bootstrap admin template.">
    <meta name="author" content="Muhammad Usman">

    <!-- The styles -->
    <link   href="asset/css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="asset/css/charisma-app.css" rel="stylesheet">
    <link href='asset/bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='asset/bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='asset/bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='asset/bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='asset/bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='asset/bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='asset/css/jquery.noty.css' rel='stylesheet'>
    <link href='asset/css/noty_theme_default.css' rel='stylesheet'>
    <link href='asset/css/elfinder.min.css' rel='stylesheet'>
    <link href='asset/css/elfinder.theme.css' rel='stylesheet'>
    <link href='asset/css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='asset/css/uploadify.css' rel='stylesheet'>
    <link href='asset/css/animate.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="asset/bower_components/jquery/jquery.min.js"></script>

   
    <!-- The fav icon -->
    <link rel="shortcut icon" href="asset/img/favicon.ico">

</head>
<style type="text/css">
    body, html {
    height: 100%;
}


.bg { 
    /* The image used */
    background-image: url("ddd.png");

    /* Full height */
    height: 100%;

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
<body class="bg-light">
    <header>
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                    <h1> </h1>
                        <h1> PK Applications</h1>
                        <p>Bergabunglah untuk menjadi bagian dari kami</p>
                   
                    <br>
<br>
 <section>
        <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <img src="logo.jpeg" width="370"/>
                    </div>
                </div>
            </div>
    </section>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
                  
 <div class="col-sm-5 col-lg-5">
    <form action="" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input class="form-control" type="text" name="username" placeholder="Email" />
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input class="form-control" type="password" name="password" placeholder="Password" />
            </div><br>

            <center><a class=" btn btn-info " href="hrd/register.php"><i class="  glyphicon glyphicon-edit"></i><span> Register</span></a>  <input type="submit" class="btn btn-success " name="login" value="Masuk"/></center>
            
    </form>
</div> 
<?php
session_start(); 
  $conn = mysqli_connect('localhost','root','','rekrut');
  if(ISSET($_POST['login'])){
    
    $username = $_POST['username'];
    $password = $_POST['password'];


    // Mulai Fungsi Log-in 
    $query = "select * from pengguna where email='".$username."'";
    $execute = mysqli_query($conn, $query);
    $num = mysqli_num_rows($execute);

    if($num>0){
      $data = mysqli_fetch_array($execute);
        if (password_verify($password, $data['password'])) {
              $id_user = $data['id'];
              $level = $data['level'];
              $_SESSION['id_user'] = $data['id'];
              $_SESSION['nama'] = $data['nama'];
 
              if ($level == "HRD") { 
                echo "<script> window.location='hrd/index.php'; </script>";
              }elseif ($level == "Pelamar") {  
                echo"<script> window.location='pelamar/index.php'; </script>";
              }
        } else {
            echo 'Invalid password.';
        }
      

    }else{
      echo "<script> alert ('Login Gagal'); </script>";
    }

  }
?>    

</body>
<!-- external javascript -->

<script src="asset/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- library for cookie management -->
<script src="asset/js/jquery.cookie.js"></script>
<!-- calender plugin -->
<script src='asset/bower_components/moment/min/moment.min.js'></script>
<script src='asset/bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
<!-- data table plugin -->
<script src='asset/js/jquery.dataTables.min.js'></script>

<!-- select or dropdown enhancer -->
<script src="asset/bower_components/chosen/chosen.jquery.min.js"></script>
<!-- plugin for gallery image view -->
<script src="asset/bower_components/colorbox/jquery.colorbox-min.js"></script>
<!-- notification plugin -->
<script src="asset/js/jquery.noty.js"></script>
<!-- library for making tables responsive -->
<script src="asset/bower_components/responsive-tables/responsive-tables.js"></script>
<!-- tour plugin -->
<script src="asset/bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
<!-- star rating plugin -->
<script src="asset/js/jquery.raty.min.js"></script>
<!-- for iOS style toggle switch -->
<script src="asset/js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="asset/js/jquery.autogrow-textarea.js"></script>
<!-- multiple file upload plugin -->
<script src="asset/js/jquery.uploadify-3.1.min.js"></script>
<!-- history.js for cross-browser state change on ajax -->
<script src="asset/js/jquery.history.js"></script>
<!-- application script for Charisma demo -->
<script src="asset/js/charisma.js"></script>


</body>
</html>