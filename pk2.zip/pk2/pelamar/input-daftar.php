<?php session_start();
  $conn = mysqli_connect('localhost','root','','rekrut');
 
// menangkap data yang di kirim dari form
//$id_daftar= $_POST['id_daftar'];
$posisi= $_POST['posisi'];
$no_ktp= $_POST['no_ktp'];
$nama= $_POST['nama'];
$tempat_lahir= $_POST['tempat_lahir'];
$tgl_lahir= $_POST['tgl_lahir'];
$alamat= $_POST['alamat'];
$jenis_kelamin= $_POST['jenis_kelamin'];
$pendidikan= $_POST['pendidikan'];
$email= $_POST['email'];
$no_hp = $_POST['no_hp'];
$tb = $_POST['tb'];
$bb = $_POST['bb'];
$id_pengguna = $_SESSION['id_user'];
$id_lowongan = $_POST['id_lowongan'];

#cek apakah sudah ada pengajuan atau belum
$eksekusi = mysqli_query($conn, "SELECT * from pelamar where id_pengguna ='$id_pengguna' AND status != 2");
$data = mysqli_fetch_array($eksekusi);
if(!empty($data)){ ?>
<script type="text/javascript">
    alert('Maaf, Pengajuan sebelumnya belum dikonfirmasi');
    history.back();
</script>
<?php
exit;
}

 #upload file 
    $ekstensi_diperbolehkan = array('png','jpg');
    $foto       = $_FILES['file']['name']; 
    $x          = explode('.', $foto);
    $ekstensi   = strtolower(end($x));
    $ukuran     = $_FILES['file']['size'];
    $file_tmp   = $_FILES['file']['tmp_name'];  

    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
        if($ukuran < 1000000){          
            move_uploaded_file($file_tmp, '../ktp/'.$foto);  }
        else{ ?> 
            <script type="text/javascript">
                alert('UKURAN FILE TERLALU BESAR');
                history.back();
            </script>
        <?php }
    }else{ ?>
        <script type="text/javascript">
                alert('UKURAN FILE TERLALU BESAR');
                history.back();
            </script>
    <?php }
$eksekusi = mysqli_query($conn, "INSERT into pelamar values('','$id_pengguna','$id_lowongan','$posisi', '$no_ktp', '$foto', '$nama', '$tempat_lahir','$tgl_lahir','$alamat', '$jenis_kelamin', '$pendidikan', '$email', '$no_hp', '$tb', '$bb','$foto')");
if($eksekusi){ ?>
        <script type="text/javascript">
            alert('Berhasil Daftar');
            window.location = 'index.php';
        </script>
    <?php }else{ ?>
        <script type="text/javascript">
            alert('Maaf, Anda telah terdaftar');
            window.location = 'index.php';
        </script>
    <?php } ?>




