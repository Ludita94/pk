<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <title>halaman Daftar</title>
   

    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">

    <link href="css/charisma-app.css" rel="stylesheet">
    <link href='bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>
    <link href='css/noty_theme_default.css' rel='stylesheet'>
    <link href='css/elfinder.min.css' rel='stylesheet'>
    <link href='css/elfinder.theme.css' rel='stylesheet'>
    <link href='css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='css/uploadify.css' rel='stylesheet'>
    <link href='css/animate.min.css' rel='stylesheet'>

    <!-- jQuery -->
    <script src="bower_components/jquery/jquery.min.js"></script>
</head>

<body>
    <!-- topbar starts -->
    <div class="navbar navbar-default" role="navigation">

        <div class="navbar-inner">
            <button type="button" class="navbar-toggle pull-left animated flip">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"> <img src="../asset/image/logo.jpeg" >PK Applications</a>
            <ul class="collapse navbar-collapse nav navbar-nav top-menu">

                <li class="dropdown">

                </li>
                <li>
                    <form class="navbar-search pull-left">

                    </form>
                </li>
            </ul>

        </div>
    </div>
    <!-- topbar ends -->
    <div class="ch-container">
        <div class="row">

            <!-- left menu starts -->

            <ul class="collapse navbar-collapse nav navbar-nav top-menu">

                <li class="dropdown">

                </li>
                <li>
                    <form class="navbar-search pull-left">

                    </form>
                </li>
            </ul>

        </div>
    </div>
    <!-- topbar ends -->
    <div class="ch-container">
        <div class="row">

            <!-- left menu starts -->
            <div class="col-sm-2 col-lg-2">
                <div class="sidebar-nav">
                    <div class="nav-canvas">
                        <div class="nav-sm nav nav-stacked">
                        </div>
                        <ul class="nav nav-pills nav-stacked main-menu">
                            <li><a class="ajax-link" href="../pelamar/index.php"><i class="glyphicon glyphicon-home"></i><span> Dashboard</span></a>
                            </li>
                            
                        </ul>

                    </div>
                </div>
            </div>

<?php
 $conn = mysqli_connect('localhost','root','','rekrut');
    $id_lowongan = $_GET['id_lowongan'];
    $query = "select * from lowongan where id_lowongan='".$id_lowongan."'";
    $execute = mysqli_query($conn, $query);
    $data = mysqli_fetch_array($execute);
    $posisi = $data['posisi'];
   
        
        ?>
            <center>
                <div class="row">
                    <div class="box col-md-8">
                        <div class="box-inner">
                            <div class="box-header well" data-original-title="">
                                <h2><i class="glyphicon glyphicon-edit"></i> Form Daftar</h2>

                                <div class="box-icon">

                                    <a href="#" class="btn btn-minimize btn-round btn-default"><i class="glyphicon glyphicon-chevron-up"></i></a>
                                    <a href="#" class="btn btn-close btn-round btn-default"><i class="glyphicon glyphicon-remove"></i></a>
                                </div>
                            </div>
                            <br>
                            <form action="input-daftar.php" method="POST"  enctype="multipart/form-data">
                                <div class="content">
                                    <table class="table-form" border="4" width="80%" cellpadding="" cellspacing="">
                                    <tr>
                                            <td width="20%"><label for="posisi">Posisi</label></td>
                                            <td colspan="3">
                                                <input readonly="" value="<?= $posisi; ?>" name="posisi" id="posisi" type="text" class="form-control" required="required">
                                                <input style="display: none;" value="<?= $id_lowongan; ?>" name="id_lowongan" type="text" class="form" required="required">
                                            </td>
                                        </tr>
                                         <td width="20%"><label for="nama">Nama Lengkap</label></td>
                                            <td colspan="3"><input value="<?= $_SESSION['nama']; ?>" readonly name="nama" id="nama" type="text" class="form-control" required="required"></td>
                                        </tr>

                                        <tr>
                                            <td width="20%"><label for="no_ktp">No KTP</label></td>
                                            <td><input name="no_ktp" id="no_ktp" type="integer" class="form-control" required="required"></td>
                                            <td width="20%"><label for="no_ktp">Upload Scan KTP</label></td>
                                            <td><input name="file"  type="file"  required="required"></td> 
                                        </tr>
                                        <tr>
                                            <td><label name="tempat_lahir">Tempat Lahir</label></td>
                                            <td><input name="tempat_lahir" id="tempat_lahir" type="text" class="form-control" required="required"></td>
                                            <td><label>Tanggal Lahir</label></td>
                                            <td>
                                                <input type="date" name="tgl_lahir">
                                           
                                            </td>
                                        </tr>
                                        <tr>
                                            <td valign="top"><label for="alamat">Alamat</label></td>
                                            <td valign="top" colspan="2">
                                                <textarea name="alamat" class="form-control" id="alamat" class="form" cols="50" rows="4" required="required"></textarea>
                                            </td>
                                            <td valign="top">
                                                <div>
                                                    <label for="jenis_kelamin">Jenis Kelamin</label>
                                                    <br> 
                                                    <select name="jenis_kelamin" class="form-control"  required="required">
                                                        <option value="Laki-laki"> Laki-laki </option>
                                                        <option value="Wanita"> Perempuan </option>
                                                    </select>
                                                    <br>
                                                </div>
                                                <div>
                                                    <label for="pendidikakn">Pendidikan</label>
                                                    <br>
                                                    <input type="text" name="pendidikan" id="pendidikan" class="form-control" required="required">
                                                    <br>
                                                </div>
                                                <div>
                                                    <label for="email">Email</label> 
                                                    <input class="form-control" type="email" name="email" id="email" required="required">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><label for="no_hp">No. HP</label></td>
                                            <td colspan="3"><input name="no_hp" id="no_hp" type="integer" class="form-control"  required="required"></td>
                                        </tr>
                        
                                        <tr>
                                            <td><label for="tb">Tinggi Badan</label></td>
                                            <td colspan="3"><input name="tb" id="tb" type="integer" class="form-control" required="required"></td>
                                        </tr>
                                        <tr>
                                            <td><label for="bb">Berat Badan</label></td>
                                            <td colspan="3"><input name="bb" id="bb" type="integer" class="form-control" required="required"></td>
                                        </tr>
                                    </table>
                                </div>
                                <br>
                                <div class="form-group">
                                    <center><button class="btn btn-success" type="submit">submit<a href="../hrd/table.php"></button> </center>
                                </div>
                            </form>
            </center>
            <!-- external javascript -->

            <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

            <!-- library for cookie management -->
            <script src="js/jquery.cookie.js"></script>
            <!-- calender plugin -->
            <script src='bower_components/moment/min/moment.min.js'></script>
            <script src='bower_components/fullcalendar/dist/fullcalendar.min.js'></script>
            <!-- data table plugin -->
            <script src='js/jquery.dataTables.min.js'></script>

            <!-- select or dropdown enhancer -->
            <script src="bower_components/chosen/chosen.jquery.min.js"></script>
            <!-- plugin for gallery image view -->
            <script src="bower_components/colorbox/jquery.colorbox-min.js"></script>
            <!-- notification plugin -->
            <script src="js/jquery.noty.js"></script>
            <!-- library for making tables responsive -->
            <script src="bower_components/responsive-tables/responsive-tables.js"></script>
            <!-- tour plugin -->
            <script src="bower_components/bootstrap-tour/build/js/bootstrap-tour.min.js"></script>
            <!-- star rating plugin -->
            <script src="js/jquery.raty.min.js"></script>
            <!-- for iOS style toggle switch -->
            <script src="js/jquery.iphone.toggle.js"></script>
            <!-- autogrowing textarea plugin -->
            <script src="js/jquery.autogrow-textarea.js"></script>
            <!-- multiple file upload plugin -->
            <script src="js/jquery.uploadify-3.1.min.js"></script>
            <!-- history.js for cross-browser state change on ajax -->
            <script src="js/jquery.history.js"></script>
            <!-- application script for Charisma demo -->
            <script src="js/charisma.js"></script>


</body>

</html>