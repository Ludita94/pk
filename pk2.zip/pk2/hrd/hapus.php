<?php
require_once("../config/conn.php");
 $conn = mysqli_connect('localhost','root','','rekrut');
$id_daftar = $_GET['id_daftar'];
$sql = "DELETE FROM pelamar WHERE id_daftar = '$id_daftar'"; // query hapus data
if(mysqli_query($conn, $sql)){
    header("Location: ../hrd/table.php"); // redirect ke index.php
}else{
    echo "Hapus data gagal";
}
?>