<?php 
 $conn = mysqli_connect('localhost','root','','rekrut');
  $id = $_REQUEST['id_lowongan']; 
  $sql = "SELECT * FROM lowongan WHERE id_lowongan='$id'"; 
  $result = mysqli_query($conn, $sql); 
  $show = mysqli_fetch_array($result); 
?>
<html>
<head>
  <title>Edit</title>
</head>
<body>
  <form method="post" action="update.php">
    <input type="hidden" name='ID' value="<?php echo $show['id']; ?>" /><br /> 
    id : <input type="text" name="id_lowongan" value="<?php echo $show['id_lowongan']; ?>" /><br /> 
    tgl_post: <input type="date" name="tgl_post" value="<?php echo $show['tgl_post']; ?>" /><br /> 
    posisi : <input type="text" name="posisi" value="<?php echo $show['posisi']; ?>" /><br /> 
    kriteria : <input type="text" name="kriteria" value="<?php echo $show['kriteria']; ?>" /><br /> 
    tgl_close : <input type="date" name="tgl_close" value="<?php echo $show['tgl_close']; ?>" /><br /> 
    keterangan : <input type="text" name="keterangan" value="<?php echo $show['keterangan']; ?>" /><br /> 
    <input type="submit" value="Update" /> 
  </form> 
</body> 
</html>