<?php
include '../config/conn.php';
 
// menangkap data yang di kirim dari form
$id_lowongan= $_POST['id_lowongan'];
$tgl_post= $_POST['tgl_post'];
$posisi= $_POST['posisi'];
$kriteria= $_POST['kriteria'];
$tgl_close = $_POST['tgl_close'];
$keterangan = $_POST['keterangan'];

// menginput data ke database
$conn = mysqli_connect('localhost','root','','rekrut');
$eksekusi= mysqli_query($conn, "INSERT into lowongan values('$id_lowongan', '$tgl_post', '$posisi', '$kriteria','$tgl_close','$keterangan')");
if($eksekusi){ ?>
        <script type="text/javascript">
            alert('Berhasil Posting Loker');
            window.location = '../hrd/halaman-loker.php';
        </script>
    <?php }else{ ?>
        <script type="text/javascript">
            alert('Maaf, Posting Loker Gagal');
            //window.location = 'posting.php';
        </script>
    <?php } ?>
