<?php 
 $conn = mysqli_connect('localhost','root','','rekrut');
$id_daftar = $_GET['id_daftar'];
$stt    = $_GET['stt'];

$sql = "UPDATE pelamar SET status='$stt' WHERE id_daftar='$id_daftar'"; // query hapus data
$eksekusi = mysqli_query($conn,$sql);
if($eksekusi){ ?>
    <script type="text/javascript">
        alert('Berhasil di Konfirmasi');
        window.location = 'table.php';
    </script>
<?php }else{ ?>
    <script type="text/javascript">
        alert('Maaf, Gagal Konfirmasi');
        window.location = 'table.php';
    </script>
<?php } ?>