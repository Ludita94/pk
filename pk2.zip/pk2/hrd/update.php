<?php
 $conn = mysqli_connect('localhost','root','','rekrut');
  $id_lowongan = $_REQUEST['id_lowongan'];
  $tgl_post = $_REQUEST['tgl_post'];
  $posisi = $_REQUEST['posisi'];
  $kriteria = $_REQUEST['kriteria'];
  $tgl_close = $_REQUEST['tgl_close'];
  $keterangan = $_REQUEST['keterangan'];
 
  
  //KONDISI 
  if (!empty($id_lowongan) && !empty($tgl_post) && !empty($posisi) && !empty($kriteria) && !empty($tgl_close) && !empty($keterangan)) { 
    $sqli = ("UPDATE lowongan SET tgl_post='$tgl_post',posisi='$posisi',kriteria='$kriteria',tgl_close='$tgl_close',keterangan='$keterangan' WHERE id_lowongan='$id_lowongan'"); 
    $result = mysqli_query($conn, $sqli);  
    
    if($result){ ?>
        <script type="text/javascript">
            alert('Berhasil di Update');
            window.location = 'halaman-loker.php';
        </script>
    <?php }else{ ?>
        <script type="text/javascript">
            alert('Maaf, Gagal di Update');
            window.location = 'halaman-loker.php';
        </script>
    <?php } 
  }
  
  mysqli_close($conn);  
?>