<?php
$conn = mysqli_connect('localhost','root','','rekrut');
$id_lowongan = $_GET['id_lowongan'];
$sql =" DELETE FROM lowongan WHERE id_lowongan = $id_lowongan"; // query hapus data
		if(mysqli_query($conn, $sql)){
		}else{
    	echo "Hapus data gagal";
		}
	echo"<script> window.location='../hrd/halaman-loker.php'; </script>";	
?>



