<?php
$conn = mysqli_connect('localhost','root','','rekrut');
$id_lowongan = $_GET['id'];
$sql =" DELETE FROM lowongan WHERE id_lowongan = $id_lowongan"; // query hapus data
		if(mysqli_query($conn, $sql)){
		}else{
    	echo "Hapus data gagal";
		}
?>



